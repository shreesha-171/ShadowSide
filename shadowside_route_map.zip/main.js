// ShadowSide Route Map - main.js
// Dependencies: Leaflet, SunCalc
// Uses public OSRM routing and Nominatim geocoding (no API keys required).

const map = L.map('map').setView([12.9716, 77.5946], 12);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '© OpenStreetMap contributors'
}).addTo(map);

let routeLayer = null;
let shadowPolylines = [];

document.getElementById('btn-route').addEventListener('click', getRoute);

async function getRoute() {
  const startInput = document.getElementById('start').value.trim();
  const endInput = document.getElementById('end').value.trim();
  const dateInput = document.getElementById('travel-time').value;

  if (!startInput || !endInput) {
    alert('Please enter both start and end points.');
    return;
  }

  const startTime = dateInput ? new Date(dateInput) : new Date();
  // Convert inputs to coordinates (lat, lon)
  const startCoords = await getCoordinates(startInput);
  const endCoords = await getCoordinates(endInput);

  if (!startCoords || !endCoords) {
    alert('Failed to resolve one or both locations. Try coordinates like: 12.9176,77.5729');
    return;
  }

  const osrmUrl = `https://router.project-osrm.org/route/v1/driving/${startCoords.lon},${startCoords.lat};${endCoords.lon},${endCoords.lat}?overview=full&geometries=geojson&alternatives=true`;

  let res;
  try {
    res = await fetch(osrmUrl);
  } catch (err) {
    alert('Error fetching route: ' + err.message);
    return;
  }

  if (!res.ok) {
    alert('Routing service returned an error: ' + res.status);
    return;
  }

  const data = await res.json();
  if (!data.routes || data.routes.length === 0) {
    alert('No routes found.');
    return;
  }

  // cleanup previous layers
  if (routeLayer) { map.removeLayer(routeLayer); routeLayer = null; }
  shadowPolylines.forEach(p => map.removeLayer(p));
  shadowPolylines = [];

  // Draw first route (primary)
  const primary = data.routes[0];
  const coords = primary.geometry.coordinates.map(c => [c[1], c[0]]);
  routeLayer = L.polyline(coords, { color: '#1f7ae0', weight:5, opacity:0.9 }).addTo(map);
  map.fitBounds(routeLayer.getBounds(), {padding:[40,40] });

  // Compute shadow analysis
  computeShadowAnalysis(primary, startTime);
}

// compute shadow distribution along route
function computeShadowAnalysis(route, startTime) {
  const routeCoords = route.geometry.coordinates.map(c => [c[1], c[0]]); // [lat, lon]
  const distanceKm = (route.distance / 1000).toFixed(1);
  const durationMin = Math.round(route.duration / 60);

  // sampling interval - number of points to skip between samples
  const interval = Math.max(1, Math.floor(routeCoords.length / 200)); // ~200 samples max

  let leftCount = 0, rightCount = 0, frontCount = 0, backCount = 0;
  let samples = 0;

  for (let i = 0; i < routeCoords.length - 1; i += interval) {
    const [lat1, lon1] = routeCoords[i];
    const [lat2, lon2] = routeCoords[Math.min(i+interval, routeCoords.length-1)];

    const bearing = getBearing(lat1, lon1, lat2, lon2);

    // approximate time along the route proportionally
    const timeAtPoint = new Date(startTime.getTime() + (i / (routeCoords.length-1)) * route.duration * 1000);

    const sunPos = SunCalc.getPosition(timeAtPoint, lat1, lon1);
    // SunCalc returns azimuth in radians from south going west => convert to degrees from north
    // sunAzimuth = (sunPos.azimuth * 180/Math.PI + 180) % 360; <-- alternative
    const sunAzimuth = (sunPos.azimuth * 180 / Math.PI + 360) % 360;
    // difference between sun direction and travel bearing
    const diff = (sunAzimuth - bearing + 360) % 360;

    // classify into 4 quadrants: front(315-45), right(45-135), back(135-225), left(225-315)
    let segColor = '#888';
    if ((diff >= 315 && diff <= 360) || (diff >= 0 && diff < 45)) {
      frontCount++; segColor = '#f59e0b'; // orange
    } else if (diff >= 45 && diff < 135) {
      rightCount++; segColor = '#ef4444'; // red
    } else if (diff >= 135 && diff < 225) {
      backCount++; segColor = '#10b981'; // green
    } else { // 225 - 315
      leftCount++; segColor = '#2563eb'; // blue
    }

    // draw small segment to visualize classification
    const segment = L.polyline([[lat1, lon1], [lat2, lon2]], { color: segColor, weight: 4, opacity: 0.45 }).addTo(map);
    shadowPolylines.push(segment);

    samples++;
  }

  const total = leftCount + rightCount + frontCount + backCount || 1;
  const leftPct = ((leftCount / total) * 100).toFixed(1);
  const rightPct = ((rightCount / total) * 100).toFixed(1);
  const frontPct = ((frontCount / total) * 100).toFixed(1);
  const backPct = ((backCount / total) * 100).toFixed(1);

  const sunTimes = SunCalc.getTimes(new Date(), routeCoords[0][0], routeCoords[0][1]);

  document.getElementById('sun-times').innerText = `Sunrise: ${sunTimes.sunrise.toLocaleTimeString()} | Sunset: ${sunTimes.sunset.toLocaleTimeString()}`;
  document.getElementById('shadow-summary').innerText =
    `Route Distance: ${distanceKm} km | Duration: ${durationMin} min\n` +
    `Shadow Analysis:\nLEFT: ${leftPct}%\nRIGHT: ${rightPct}%\nFRONT: ${frontPct}%\nBACK: ${backPct}%\n` +
    `Samples: ${samples}`;
}

// get bearing between two lat/lon points (degrees from north)
function getBearing(lat1, lon1, lat2, lon2) {
  const φ1 = lat1 * Math.PI / 180;
  const φ2 = lat2 * Math.PI / 180;
  const Δλ = (lon2 - lon1) * Math.PI / 180;
  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
  const θ = Math.atan2(y, x);
  return (θ * 180 / Math.PI + 360) % 360;
}

// geocoding using Nominatim (public)
async function getCoordinates(input) {
  // if input looks like lat,lon return directly
  if (/^-?\d+(\.\d+)?\s*,\s*-?\d+(\.\d+)?$/.test(input)) {
    const parts = input.split(',').map(s => s.trim());
    return { lat: parseFloat(parts[0]), lon: parseFloat(parts[1]) };
  }

  const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(input)}`;
  try {
    const res = await fetch(url, { headers: { 'Accept-Language': 'en' } });
    if (!res.ok) return null;
    const data = await res.json();
    if (!data || data.length === 0) return null;
    return { lat: parseFloat(data[0].lat), lon: parseFloat(data[0].lon) };
  } catch (err) {
    console.error('Geocode error', err);
    return null;
  }
}

// Prevent accidental page zoom by wheel
map.getContainer().addEventListener('wheel', function (e) {
  if (e.ctrlKey) return;
  e.preventDefault();
}, { passive: false });
